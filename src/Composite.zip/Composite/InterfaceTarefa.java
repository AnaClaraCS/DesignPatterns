package Composite;

public interface InterfaceTarefa {
    public String getDescricao();
    public boolean getStatus();
}
