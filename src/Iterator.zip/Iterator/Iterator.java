package Iterator;

public interface Iterator {
    public Produto getNext();
    public boolean hasMore();

}
