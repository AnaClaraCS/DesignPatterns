package Strategy;
public interface Estrategia {
    public void ataque();
    public String getNome();
}
