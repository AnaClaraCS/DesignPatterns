package Prototype;

public interface InterfacePrototype {
    public InterfacePrototype clone();
}
