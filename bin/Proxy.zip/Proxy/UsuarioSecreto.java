package Proxy;

public class UsuarioSecreto implements Usuario{

    public int nivelAcesso() {
        return 3;       
    }

}
