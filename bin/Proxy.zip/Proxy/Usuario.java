package Proxy;

public interface Usuario {
    public int nivelAcesso();     
}
