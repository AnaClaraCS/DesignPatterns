package Proxy;
public class InformacaoAltamenteSecreta implements Informacao{

    public String acesso() {
        return "Informação altamente secreta";
    }

    public int nivelAcesso() {
        return 4;       
    }

}
