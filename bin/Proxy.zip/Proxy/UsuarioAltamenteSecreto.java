package Proxy;

public class UsuarioAltamenteSecreto implements Usuario{

    public int nivelAcesso() {
        return 4;       
    }
}
