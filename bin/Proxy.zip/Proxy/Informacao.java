package Proxy;
public interface Informacao {
    public String acesso();
    public int nivelAcesso();
}
